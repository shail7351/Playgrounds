import UIKit

enum LibraryType {
  case songs
  case albums
  case books
  case movies
}

struct Library {
  let name: String
  let artistName: String
  let artwork: String
  
  static func generateDummyLib() -> Array<Library> {
    [Library(name: "SOS",
             artistName: "SZA",
             artwork: "https://is3-ssl.mzstatic.com/image/thumb/Music122/v4/bd/3b/a9/bd3ba9fb-9609-144f-bcfe-ead67b5f6ab3/196589564931.jpg/100x100bb.jpg"),
    Library(name: "One Thing At A Time",
            artistName: "Morgan Wallen",
            artwork: "https://is3-ssl.mzstatic.com/image/thumb/Music123/v4/86/cc/00/86cc001c-2efc-9ebb-8290-17f4f3ba3e4a/23UMGIM08087.rgb.jpg/100x100bb.jpg"),
    Library(name: "The Secret Weapon",
            artistName: "artistName",
            artwork: "https://is4-ssl.mzstatic.com/image/thumb/Music126/v4/39/10/7f/39107f7e-2354-075c-32d7-f1955c06f709/075679698506.jpg/100x100bb.jpg")]
  }
}

protocol LibraryProtocol {
  func getLibrary() -> Array<Library>
}

class SongsLibrary: LibraryProtocol {
  func getLibrary() -> Array<Library> {
    print("This is Songs Library")
    return Library.generateDummyLib()
  }
}

class AlbumsLibrary: LibraryProtocol {
  func getLibrary() -> Array<Library> {
    print("This is Albums Library")
    return Library.generateDummyLib()
  }
}

class BooksLibrary: LibraryProtocol {
  func getLibrary() -> Array<Library> {
    print("This is Books Library")
    return Library.generateDummyLib()
  }
}

class MoviesLibrary: LibraryProtocol {
  func getLibrary() -> Array<Library> {
    print("This is Movies Library")
    return Library.generateDummyLib()
  }
}

class LibraryFactory {
  static func create(type: LibraryType) -> LibraryProtocol {
    switch type {
    case .songs:
      return SongsLibrary()
    case .albums:
      return AlbumsLibrary()
    case .books:
      return BooksLibrary()
    case .movies:
      return MoviesLibrary()
    }
  }
}

class LibraryViewModel {
  private let library: LibraryProtocol
  
  init(_library: LibraryProtocol) {
    library = _library
  }
  
  func getLibrary() -> Array<Library> {
    return library.getLibrary()
  }
}

let libraryViewModel = LibraryViewModel(_library: LibraryFactory.create(type: .movies))
libraryViewModel.getLibrary()
